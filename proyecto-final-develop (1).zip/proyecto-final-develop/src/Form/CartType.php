<?php

namespace App\Form;

use App\Entity\Game;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class CartType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        /** @var Game $game */
        $game = array_shift($options['data']);

        $builder
            ->add('id', HiddenType::class,[
                'mapped' => false,
                'data' => $game->getId()
            ])
            ->add('quantity', IntegerType::class,[
                'mapped' => false,
                'data' => 1,
                'attr' => [
                    'class' => 'form-control',
                    'min' => 1,
                    'max' => 21
                ]
            ])
            ->add('add', SubmitType::class,[
                'attr' => [
                    'class' => 'nk-btn nk-btn-rounded nk-btn-color-main-1',
                ]
            ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
          'data' => Game::class
        ]);
    }
}
