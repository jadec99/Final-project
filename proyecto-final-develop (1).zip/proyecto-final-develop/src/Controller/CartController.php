<?php

namespace App\Controller;

use App\Entity\Address;
use App\Entity\Game;
use App\Entity\LineItem;
use App\Entity\Order;
use App\Entity\User;
use App\Events\OrderEvent;
use App\Events\UserEvent;
use App\Repository\GameRepository;
use App\Repository\UserRepository;
use Doctrine\ORM\EntityManagerInterface;
use Psr\EventDispatcher\EventDispatcherInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;

/**
 * @Route("/cart", name="app_cart")
 */
class CartController extends AbstractController
{
    private GameRepository $gameRepository;

    private SessionInterface $session;

    private EntityManagerInterface $entityManager;

    private EventDispatcherInterface $dispatcher;

    public function __construct(
        GameRepository $gameRepository,
        SessionInterface $session,
        EntityManagerInterface $entityManager,
        EventDispatcherInterface $dispatcher
    ) {

        $this->gameRepository = $gameRepository;
        $this->session = $session;
        $this->entityManager = $entityManager;
        $this->dispatcher=$dispatcher;
    }

    /**
     * @Route("/add", name="_add", methods={"POST"} )
     */
    public function add(Request $request): Response
    {
        $postData = $request->request->all();

        unset($postData['cart']['add']);

        if(null == $this->session->get('cartItems')){
            $items = [];
        } else {
            $items = $this->session->get('cartItems');
        }

        /** @var Game $game */
        $game = $this->gameRepository->find($postData['cart']['id']);
        if( $game === null ) {
            throw new Exception('the game not exist or has been removed');
        }

        $items[$game->getId()]=['quantity'=> $postData['cart']['quantity'],'game'=>$game];
        $this->session->set('cartItems', $items);

        return $this->redirectToRoute('app_cart_view');

    }

    /**
     * @Route("/view", name="_view", methods={"GET"})
     */
    public function viewCart() : Response
    {
        return $this->render('cart/index.html.twig', []);
    }

    /**
     * @Route("/del/{idItem}", name="_del", methods={"GET"})
     */
    public function del(Request $request, string $idItem): Response
    {
        $items = $this->session->get('cartItems');

        if(!isset($items[$idItem])){
            throw new Exception('the game not exist or has been removed from session');
        }

        unset($items[$idItem]);

        $this->session->set('cartItems', $items);

        return $this->redirectToRoute('app_cart_view');
    }

    /**
     * @Route("/update/{id}", name="_update", methods={"GET"})
     * @ParamConverter("game", class="App:Game")
     */
    public function update(Request $request, Game $game): Response
    {
        $quantity = $request->query->get('cart')['quantity'];
        if(null === $quantity){
            throw new Exception('quantity required for the item');
        }
        $items = $this->session->get('cartItems');

        $items[$game->getId()] = [
            'quantity'=> intval($quantity),
            'game'=>$game
        ];

        $this->session->set('cartItems', $items);

        return $this->redirectToRoute('app_cart_view');
    }


    /**
     * @Route("/checkout", name="_checkout", methods={"GET","POST"})
     * @throws \Exception
     */
    public function checkout(Request $request,UserRepository $userRepository): Response
    {
        /** @var User $user */
        $user = $this->getUser();
        $parameters = $request->request->all();
        if('POST' == $request->getMethod()) {

            $this->billingAddress($parameters);
            $order = $this->persistOrder($user);
            $this->emptyCart();

            $this->dispatcher->dispatch(new OrderEvent($order,$user),OrderEvent::NAME);

            return $this->redirectToRoute('app_cart_view');

        }

        return $this->render('cart/checkout.html.twig', []);

    }

    private function persistOrder(User $user): Order {

        $items = $this->session->get('cartItems');

        $order = new Order();
        $order->setAmount($this->getOrderTotal($items));
        $order->setUser($user);

        foreach ($items as $item => $data) {
            $lineItem = new LineItem();
            $lineItem->setQuantity($data['quantity']);
            $game = $this->gameRepository->find($item);
            $lineItem->setGame($game);

            $order->addLineItem($lineItem);
        }

        $this->entityManager->persist($order);
        $this->entityManager->flush();

        return $order;

    }

    private function getOrderTotal(array $items) : float
    {
        $sub_total = 0;

        foreach ($items as $itemId => $item) {
            /** @var Game $game */
            $game = $item['game'] ;
            $sub_total += $game->getPrice() * intval($item['quantity']);
        }

        return number_format($sub_total,2);
    }

    /**
     * @throws \Exception
     */
    private function billingAddress(array $parameters)
    {
        /** @var User $user */
        $user = $this->getUser();
        if(null == $user) {
            throw new \Exception('the user is not logged');
        }

        $user->setName($parameters['name']);
        $user->setLastName($parameters['lastName']);
        $user->setPhone($parameters['phone']);

        if( null === $user->getAddress()) {
            $address = new Address();
        } else {
            $address = $user->getAddress();
        }

        $address->setCity($parameters['city']);
        $address->setAddress($parameters['address']);
        $address->setCp($parameters['cp']);
        $address->setNotes($parameters['notes']);
        $address->setState($parameters['state']);

        $user->setAddress($address);
        $this->entityManager->persist($user);
        $this->entityManager->persist($address);

        $this->entityManager->flush();
    }

    private function emptyCart()
    {
        $this->session->set('cartItems', []);
    }
}
