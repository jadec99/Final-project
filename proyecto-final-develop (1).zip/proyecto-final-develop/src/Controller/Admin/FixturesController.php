<?php

namespace App\Controller\Admin;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class FixturesController extends AbstractController
{
    private const PATH = '/var/www/projects/steam-ready.net/data/fixtures/games';

    private const API_KEY = '3435d66ef16b4cb09ba4345ca5417f7f';

    private const END_POINT = 'https://api.rawg.io/api/games/';

    private const UPLOAD_PATH = __DIR__ . '/../../../public/uploads/games';

    private const THUMBNAILS_PATH = __DIR__ . '/../../../public/uploads/thumbanails';

    private const CROPPED_PATH = __DIR__ . '/../../../public/uploads/cropped';

    /**
     * @Route("/fixtures/download", name="download_fixtures")
     */
    public function index(): Response
    {
        $games = array_filter(scandir(self::PATH),function ($e){
          return strpos($e,".json");
        });

        foreach ($games as $game)
        {
            $data = json_decode(file_get_contents(self::PATH.'/'.$game),true);
            foreach ($data['results'] as $result)
            {
                if(!file_exists(self::PATH.'/'.$result['id'])){
                    mkdir(self::PATH.'/'.$result['id'], 0700);

                    $url = sprintf("%s%s?key=%s" ,
                        self::END_POINT,
                        $result['id'],
                        self::API_KEY
                    );

                    file_put_contents(self::PATH.'/'.$result['id'].'/game.json', file_get_contents($url));
                }

            }
        }

        return $this->json("game data downloaded");

    }

    /**
     * @Route("/fixtures/crop", name="crop_images")
     */
    public function crop(): Response
    {
        $dst_x = 0;   // X-coordinate of destination point
        $dst_y = 0;   // Y-coordinate of destination point
        $src_x = 300; // Crop Start X position in original image
        $src_y = 300; // Crop Srart Y position in original image
        $dst_w = 250; // Thumb width
        $dst_h = 345; // Thumb height
        $src_w = 550; // Crop end X position in original image
        $src_h = 645; // Crop end Y position in original image

// Creating an image with true colors having thumb dimensions (to merge with the original image)
        $dst_image = imagecreatetruecolor($dst_w, $dst_h);
// Get original image


        $games = array_filter(scandir(self::UPLOAD_PATH),function ($e){
            return strpos($e,".jpg");
        });

        foreach ($games as $game){
            $src_image = imagecreatefromjpeg(self::UPLOAD_PATH.'/'. $game);
// Cropping
            imagecopyresampled($dst_image, $src_image, $dst_x, $dst_y, $src_x, $src_y, $dst_w, $dst_h, $src_w, $src_h);
// Saving
            imagejpeg($dst_image, self::CROPPED_PATH .'/' .  $game);
        }


        return $this->json("this cropped ok");

    }

    /**
     * @Route("/fixtures/images", name="images_fixtures")
     */
    public function images(): Response
    {
        $games = array_filter(scandir(self::PATH),function ($e){
            return strpos($e,".json");
        });

        foreach ($games as $game) {
            $data = json_decode(file_get_contents(self::PATH . '/' . $game), true);

            foreach ($data['results'] as $result) {

                if(!file_exists(self::THUMBNAILS_PATH.'/'.$result['id'])){
                    mkdir(self::THUMBNAILS_PATH.'/'.$result['id'], 0700);

                    $url = sprintf("%s%s/screenshots?key=%s" ,
                        self::END_POINT,
                        $result['id'],
                        self::API_KEY
                    );



                    file_put_contents(self::THUMBNAILS_PATH.'/'.$result['id'].'/game.json', file_get_contents($url));
                }
            }
        }
    }
}
