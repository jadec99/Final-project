<?php

namespace App\Controller;

use App\Entity\Game;
use App\Entity\Review;
use App\Form\CartType;
use App\Form\ReviewType;
use App\Repository\CategoryRepository;
use App\Repository\GameRepository;
use App\Repository\ReviewRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;

class HomeController extends AbstractController
{
    /** @var GameRepository */
    private GameRepository $gameRepository;

    public function __construct(GameRepository $gameRepository)
    {
        $this->gameRepository = $gameRepository;
    }

    /**
     * @Route("/catalog/{page}", name="app_catalog", methods={"GET"})
     */
    public function index(Request $request,int $page = 1): Response
    {
        $filter = $request->query->get('filter') ?? null;
        $response = $this->gameRepository->paginate($page,$filter);
        $response['mostPopular'] = $this->gameRepository->getMostPopular();

        return $this->render('home/catalog/index.html.twig', [
            'controller_name' => 'HomeController',
            'games' => $response['games'],
            'recordsByPage' => $response['recordsByPage'],
            'total' => $response['total'],
            'mostPopular' =>  $response['mostPopular']
        ]);
    }

    /**
     * @Route("/game/{id}", name="app_game_view", methods={"GET","POST"})
     * @ParamConverter("game", class="App:Game")
     */
    public function viewGame(
        Request $request,
        Game $game,
        CategoryRepository
        $categoryRepository,
        ReviewRepository $reviewRepository): Response
    {
        $form = $this->createForm(ReviewType::class, new Review());
        $cart = $this->createForm(CartType::class, [ 'game'=> $game ] );

        $form->handleRequest($request);

        if($request->getMethod() == 'POST'){
            if ($form->isSubmitted() && $form->isValid()) {
                /** @var Review $review */
                $review = $form->getData();
                $review->setGame($game);
                try {
                    $reviewRepository->add($review);
                    $this->addFlash('success',"the review saved ok !");
                } catch (\Exception $e) {
                    $this->addFlash('error',"oops! had a problem on server");
                }

                return $this->redirectToRoute('app_game_view',['id'=>$game->getId()]);
            }
        }

        return $this->render('home/game/index.html.twig', [
            'game' => $game,
            'categories' => $categoryRepository->findAll(),
            'form' => $form->createView(),
            'cart' => $cart->createView(),

        ]);
    }
}
