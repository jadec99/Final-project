<?php


namespace App\Events;

use App\Entity\Order;
use App\Entity\User;

class OrderEvent
{
    public const NAME = 'order.registered';

    private Order $order;

    private User $user;

    public function __construct(Order $order, User $user)
    {
        $this->order = $order;

        $this->user = $user;
    }

    /**
     * @return Order
     */
    public function getOrder(): Order
    {
        return $this->order;
    }

    /**
     * @param Order $order
     */
    public function setOrder(Order $order): void
    {
        $this->order = $order;
    }

    /**
     * @return User
     */
    public function getUser(): User
    {
        return $this->user;
    }

    /**
     * @param User $user
     */
    public function setUser(User $user): void
    {
        $this->user = $user;
    }

}