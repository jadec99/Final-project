<?php

namespace App\Subscriber\Order;

use App\Events\OrderEvent;
use App\Events\UserEvent;
use App\Services\Mail\MailerService;
use Psr\Log\LoggerInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Mailer\Exception\TransportExceptionInterface;

class EventsSubscriber implements EventSubscriberInterface
{
    private LoggerInterface $logger;

    private MailerService $mailerService;

    public function __construct(LoggerInterface $logger,MailerService $mailerService)
    {
        $this->logger = $logger;
        $this->mailerService = $mailerService;
    }

    public static function getSubscribedEvents(): array
    {
        return [
            OrderEvent::NAME => 'onRegistered',
        ];
    }
    public function onRegistered(OrderEvent $event)
    {
        try {
            $this->mailerService->sendEmailOrderToUser($event->getOrder(),$event->getUser());
        } catch (TransportExceptionInterface $e) {
            $this->logger->error($e->getMessage());
        }

        $this->logger->info('the order has been checkout for the user ');
    }
}