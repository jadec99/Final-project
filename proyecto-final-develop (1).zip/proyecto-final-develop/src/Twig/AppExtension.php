<?php

namespace App\Twig;

use App\Entity\Game;
use Twig\Extension\AbstractExtension;
use Twig\TwigFilter;
use Twig\TwigFunction;

class AppExtension extends AbstractExtension
{
    public function getFilters(): array
    {
        return [
            new TwigFilter('iva', [$this, 'applyIva']),
        ];
    }

    public function getFunctions(): array
    {
        return [
            new TwigFunction('sub_totals_items_cart', [$this, 'totalsItemsCart']),
        ];
    }

    public function totalsItemsCart(array $itemsCart) : string
    {
        $sub_total = 0;

        foreach ($itemsCart as $itemId => $item) {
            /** @var Game $game */
            $game = $item['game'] ;
            $sub_total += $game->getPrice() * intval($item['quantity']);
        }

        return number_format($sub_total,2);
    }

    public function applyIva($totalWithoutIva) : string
    {
       return number_format((21 * $totalWithoutIva / 100) + $totalWithoutIva,2);
    }
}
