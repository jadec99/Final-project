<?php

namespace App\DataFixtures;

use App\Entity\Category;
use App\Entity\Game;
use App\Repository\CategoryRepository;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Symfony\Component\String\Slugger\AsciiSlugger;

class GameFixtures extends Fixture
{
    private const PATH = '/var/www/projects/steam-ready.net/data/fixtures/games';

    private const UPLOAD_DIR = '/var/www/projects/steam-ready.net/public/uploads/games/';

    private array $games;

    public function __construct(CategoryRepository $categoryRepository)
    {
        $this->games = array_filter(scandir(self::PATH),function ($e){
            return strpos($e,".json");
        });
    }
    public function load(ObjectManager $manager): void
    {
        $category = new Category();
        $category->setName('Generic');

        $manager->persist($category);

        foreach ($this->games as $game) {
            $data = json_decode(file_get_contents(self::PATH . '/' . $game), true);

            foreach ($data['results'] as $result) {
                $game = new Game();
                $game->setTitle($result['name']);
                $game->setPrice( number_format((float)mt_rand(200,400)/13, 2, '.', ''));
                $game->setImage($this->getImageFromUrl($result['background_image']));
                $game->setDescription($this->getFromId($result['id'],'description'));
                $game->setPlatform($this->getPlatformGame($result['parent_platforms']));
                $game->setRating(rand(0,100));
                $game->setCategory($category);
                $manager->persist($game);
            }

            $manager->flush();
        }
    }

    private function getPlatformGame(array $platforms) : array
    {
        $slugger = new AsciiSlugger();
        return array_map(function($platform) use($slugger){
            return strtolower($slugger->slug($platform['platform']['name']));
        },$platforms);

    }
    private function getImageFromUrl(string $url): string
    {
        $filename = pathinfo($url, PATHINFO_FILENAME);
        $extension = pathinfo($url, PATHINFO_EXTENSION);
        return implode(".",[$filename,$extension]);
    }

    private function getFromId(string $id,string $field): string
    {
        $data = json_decode(file_get_contents(self::PATH . '/' . $id.'/game.json'), true);

        return $data[$field];
    }
}
